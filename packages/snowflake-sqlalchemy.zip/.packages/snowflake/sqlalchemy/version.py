#
# Copyright (c) 2012-2023 Snowflake Computing Inc. All rights reserved.
#
# Update this for the versions
# Don't change the forth version number from None
VERSION = (1, 5, 1, None)
